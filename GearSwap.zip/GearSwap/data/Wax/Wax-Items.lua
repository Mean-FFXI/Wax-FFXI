--Gearsets your character will use among multiple jobs.
sets.BehemothSuit = {body="Behemoth Suit +1",hands=empty,legs=empty,feet=empty}
sets.Sheltered = {ring2="Sheltered Ring"}
sets.Capacity = {back="Mecisto. Mantle"}

sets.buff.Doom = {neck="Nicander's Necklace",back="Moonlight Cape",waist="Gishdubar Sash",ring1="Eshmun's Ring",ring2="Eshmun's Ring"}
sets.TreasureHunter = {head="Wh. Rarab Cap +1",waist="Chaac Belt"}

sets.precast.Item['Hallowed Water'] = {}
sets.precast.Item['Holy Water'] = {}

--Augmented items that you'll use among multiple jobs.

gear.herculean_wsd_head = {name="Herculean Helm", augments={'Weapon skill damage +5%','DEX+10','Accuracy+15',}}
gear.herculean_wsd_body = {name="Herculean Vest", augments={'Attack+25','Weapon skill damage +5%','DEX+9',}}
gear.herculean_matk_body = {name="Herculean Vest", augments={'Mag. Acc.+20 "Mag.Atk.Bns."+20','Crit. hit damage +1%','INT+11','Mag. Acc.+11','"Mag.Atk.Bns."+15',}}
gear.herculean_wsd_legs = {name="Herculean Trousers", augments={'Accuracy+6','Weapon skill damage +4%','STR+2',}}
gear.herculean_ta_hands = {name="Herculean Gloves", augments={'Attack+25','"Triple Atk."+4','STR+4',}}
gear.herculean_ta_feet =  {name="Herculean Boots", augments={'Accuracy+20 Attack+20','"Triple Atk."+3','Accuracy+11','Attack+2',}}

gear.taeon_phalanx_body = {name="Taeon Tabard", augments={'Phalanx +3',}}
gear.taeon_phalanx_hands = {name="Taeon Gloves", augments={'Phalanx +3',}}
gear.taeon_phalanx_feet = {name="Taeon Boots", augments={'Phalanx +3',}}
gear.taeon_pet_head = {name="Taeon Chapeau", augments={'Pet: Accuracy+25 Pet: Rng. Acc.+25','Pet: "Dbl. Atk."+5','Pet: Damage taken -4%',}}
gear.taeon_pet_hands = {name="Taeon Gloves", augments={'Pet: Accuracy+25 Pet: Rng. Acc.+25','Pet: "Dbl. Atk."+5','Pet: Damage taken -4%',}}
gear.taeon_pet_legs = {name="Taeon Tights", augments={'Pet: Accuracy+24 Pet: Rng. Acc.+24','Pet: "Dbl. Atk."+5','Pet: Damage taken -4%',}}
gear.taeon_pet_feet = {name="Taeon Boots", augments={'Pet: Accuracy+24 Pet: Rng. Acc.+24','Pet: "Dbl. Atk."+5','Pet: Damage taken -4%',}}

gear.merlinic_burst_head = {name="Merlinic Hood",augments={'Magic burst dmg.+11%','CHR+5','Mag. Acc.+1','"Mag.Atk.Bns."+11',}}
gear.merlinic_burst_body = {name="Merlinic Jubbah", augments={'"Mag.Atk.Bns."+28','Magic burst dmg.+9%','CHR+3',}}
gear.merlinic_fc_body = {name="Merlinic Jubbah", augments={'Mag. Acc.+5 "Mag.Atk.Bns."+5','"Fast Cast"+7','Mag. Acc.+8','"Mag.Atk.Bns."+12',}}
gear.merlinic_burst_legs = {name="Merlinic Shalwar", augments={'STR+1','"Mag.Atk.Bns."+26','Magic burst dmg.+7%','Accuracy+10 Attack+10','Mag. Acc.+7 "Mag.Atk.Bns."+7',}}

gear.chironic_drain_head = {name="Chironic Hat", augments={'"Drain" and "Aspir" potency +9','INT+7','Mag. Acc.+3','"Mag.Atk.Bns."+12',}}
gear.chironic_drain_body = {name="Chironic Doublet", augments={'"Drain" and "Aspir" potency +10','MND+9',}}
gear.chironic_drain_hands = {name="Chironic Gloves", augments={'Attack+17','"Drain" and "Aspir" potency +10','CHR+9','"Mag.Atk.Bns."+14',}}
gear.chironic_macc_legs = {name="Chironic Hose", augments={'Mag. Acc.+21 "Mag.Atk.Bns."+21','MND+13','Mag. Acc.+10',}}

gear.telchine_enhancedur_head = {name="Telchine Cap", augments={'"Fast Cast"+4','Enh. Mag. eff. dur. +10',}}
gear.telchine_enhancedur_body = {name="Telchine Chas.", augments={'"Fast Cast"+4','Enh. Mag. eff. dur. +10',}}
gear.telchine_enhancedur_hands = {name="Telchine Gloves", augments={'"Fast Cast"+2','Enh. Mag. eff. dur. +10',}}
gear.telchine_enhancedur_legs = {name="Telchine Braconi", augments={'"Fast Cast"+4','Enh. Mag. eff. dur. +10',}}
gear.telchine_enhancedur_feet = {name="Telchine Pigaches", augments={'"Fast Cast"+5','Enh. Mag. eff. dur. +10',}}

gear.telchine_regen_head = {name="Telchine Cap", augments={'"Fast Cast"+4','"Regen" potency+3',}}
gear.telchine_regen_body = {name="Telchine Chas.", augments={'"Fast Cast"+4','"Regen" potency+3',}}
gear.telchine_regen_hands = {name="Telchine Gloves", augments={'"Fast Cast"+5','"Regen" potency+3',}}
gear.telchine_regen_legs = {name="Telchine Braconi", augments={'"Fast Cast"+3','"Regen" potency+3',}}
gear.telchine_regen_feet = {name="Telchine Pigaches", augments={'"Fast Cast"+4','"Regen" potency+3',}}

gear.valorous_magical_pet_head = {name="Valorous Mask", augments={'Pet: "Mag.Atk.Bns."+29','Pet: Haste+2','Pet: INT+11','Pet: Attack+2 Pet: Rng.Atk.+2',}}
gear.valorous_magical_pet_legs = {name="Valorous Hose", augments={'Pet: "Mag.Atk.Bns."+25','Pet: Phys. dmg. taken -2%','Pet: INT+14',}}
gear.valorous_physical_pet_body = {name="Valorous Mail", augments={'Pet: Accuracy+30 Pet: Rng. Acc.+30','Pet: "Dbl.Atk."+1 Pet: Crit.hit rate +1','Pet: DEX+15',}}
gear.valorous_physical_pet_legs = {name="Valorous Hose", augments={'Pet: Mag. Acc.+29','Pet: STR+14','Pet: Accuracy+15 Pet: Rng. Acc.+15','Pet: Attack+14 Pet: Rng.Atk.+14',}}
gear.valorous_wsdmab_hands = {name="Valorous Mitts", augments={'"Mag.Atk.Bns."+21','Weapon skill damage +2%','Accuracy+1',}}
gear.valorous_wsdmab_feet = {name="Valorous Greaves", augments={'"Mag.Atk.Bns."+24','Weapon skill damage +2%','MND+7','Accuracy+10',}}
