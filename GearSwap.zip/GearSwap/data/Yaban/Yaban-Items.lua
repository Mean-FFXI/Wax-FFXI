--Gearsets your character will use among multiple jobs.
sets.BehemothSuit = {body="Behemoth Suit +1",hands=empty,legs=empty,feet=empty}
sets.Sheltered = {ring2="Sheltered Ring"}
sets.Capacity = {back="Mecisto. Mantle"}

sets.buff.Doom = {neck="Nicander's Necklace",back="Moonlight Cape",waist="Gishdubar Sash",ring1="Eshmun's Ring",ring2="Eshmun's Ring"}
sets.TreasureHunter = {head="Wh. Rarab Cap +1",waist="Chaac Belt"}

sets.precast.Item['Hallowed Water'] = {}
sets.precast.Item['Holy Water'] = {}

--Augmented items that you'll use among multiple jobs.

gear.gada_healing_club = {name="Gada", augments={'"Cure" potency +6%','VIT+5','Mag. Acc.+4','"Mag.Atk.Bns."+16',}}


gear.merlinic_refresh_feet = {name="Merlinic Crackows", augments={'"Conserve MP"+4','MND+4','"Refresh"+1','Accuracy+14 Attack+14',}}